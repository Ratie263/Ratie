# My personal webpage

This is the README file for the source code for my personal webpage. It can be found at <https://ratie263.github.io/Ratie/>. 

